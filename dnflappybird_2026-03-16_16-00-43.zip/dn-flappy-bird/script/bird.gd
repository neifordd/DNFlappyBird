extends Area2D

var flap_power: float = 7.5
var grav: float = 25
var velocity: float = 0
var rotate: float = 5
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.y += velocity
	velocity += grav * delta
	
	if Input.is_action_just_pressed("flap"):
		velocity = -flap_power
	else:
		velocity = velocity

	if velocity >= 0:
		rotation += deg_to_rad(rotate)
	elif velocity < 0:
		rotation -= deg_to_rad(rotate)
	else:
		return
	
	rotation = clamp(rotation, deg_to_rad(-30), deg_to_rad(45))
