extends Node2D
var scrollspeed: float = 3
@onready var screenwidth:float = get_window().size.x
signal getpoint
var hasscored = false
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	position.x -= scrollspeed
	if position.x <=  -screenwidth:
		queue_free()
	if position.x <= 110 and hasscored == false:
		hasscored = true
		emit_signal("getpoint")
