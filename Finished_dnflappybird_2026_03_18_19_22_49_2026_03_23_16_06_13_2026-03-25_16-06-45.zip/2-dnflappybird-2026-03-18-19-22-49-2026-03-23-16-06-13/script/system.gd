extends Node2D

@onready var game = preload("res://tscn/game.tscn")
@onready var menu = preload("res://tscn/menu.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	var show_game = game.instantiate()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Input.is_action_just_pressed("escape"):
		get_tree().change_scene_to_file("res://tscn/system.tscn")
		#var menus = menu.instantiate()
	

func _on_menu_quit_game() -> void:
	get_tree().quit()



func _on_menu_start_game() -> void:
	var show_game = game.instantiate()
	add_child(show_game)
	remove_child($menu)
